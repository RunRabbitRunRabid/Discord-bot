# Hero Academy Discord Bot

A feature-rich Discord bot for hero academy roleplay servers. Supports multiple characters per user, guild-specific data, daily activities, XP tracking, money management, and a live-updating leaderboard.

## Features

- **Slash commands only** — modern Discord slash command interface
- **Persistent SQLite storage** — all data survives restarts
- **Guild-specific** — characters, XP, and money never transfer between servers
- **Multiple characters per user** — up to 10 per server
- **Daily activity system** — class, study, train, and afterschool with per-character cooldowns
- **Proficiency bonuses** — extra XP when attending your proficient class
- **Live leaderboard** — single persistent message updated every minute
- **Automatic midnight reset** — cooldowns reset at midnight Ohio (Eastern) time

## Setup

### 1. Clone & install

```bash
git clone <your-repo-url>
cd hero-academy-bot
npm install
```

### 2. Create your bot

1. Go to [Discord Developer Portal](https://discord.com/developers/applications)
2. Create a **New Application**
3. Go to **Bot** → create a bot, copy the **Token**
4. Go to **OAuth2** → copy the **Client ID**
5. Under **Bot** → enable **Server Members Intent** if needed
6. Under **OAuth2 → URL Generator** → select `bot` + `applications.commands`, grant these permissions:
   - Send Messages
   - Read Messages/View Channels
   - Embed Links
   - Manage Messages (for leaderboard cleanup)
7. Use the generated URL to invite the bot to your server

### 3. Configure environment

```bash
cp .env.example .env
```

Edit `.env`:

```
DISCORD_TOKEN=your_bot_token_here
CLIENT_ID=your_application_client_id_here
```

### 4. Register slash commands

```bash
npm run deploy
```

> **Note:** Global commands can take up to 1 hour to propagate to all servers.

### 5. Run the bot

```bash
npm start
```

---

## Deployment (Railway / Render)

### Railway

1. Push the project to a GitHub repository
2. Create a new project on [Railway](https://railway.app)
3. Connect your GitHub repo
4. Set environment variables: `DISCORD_TOKEN` and `CLIENT_ID`
5. Railway will automatically run `npm start`

### Render

1. Push the project to GitHub
2. Create a new **Web Service** on [Render](https://render.com)
3. Connect your repo, set:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
4. Add environment variables: `DISCORD_TOKEN`, `CLIENT_ID`
5. Add a **Persistent Disk** mounted at `/app/data` so the SQLite database survives deploys

> **Important for Render:** Without a persistent disk, the database resets on every deploy. Set the mount path to match where `data/bot.db` is created (relative to your project root).

---

## Commands

| Command | Description |
|---|---|
| `/help` | List all commands |
| `/register` | Create a new character |
| `/list` | View all your characters and daily status |
| `/class [character]` | Attend today's class for XP (+5 bonus if proficient) |
| `/study [character]` | Study for XP |
| `/train [character]` | Train for XP |
| `/afterschool [character]` | Club/work activity for XP and money |
| `/leaderboard [channel]` | Set the live leaderboard channel (requires Manage Channels) |
| `/rename [character]` | Rename a character |
| `/delete [character]` | Delete a character permanently |
| `/spend [character] [amount]` | Spend money |
| `/donate [character] [amount]` | Add money to a character |

## Class Schedule (Ohio Eastern Time)

| Day | Class |
|---|---|
| Monday | General Studies |
| Tuesday | Training |
| Wednesday | Search and Rescue |
| Thursday | Front Line |
| Friday | Support |
| Saturday | Quirk Control |
| Sunday | Field Training |

## Daily Cooldowns

`/class`, `/study`, `/train`, and `/afterschool` each have **independent** once-per-day cooldowns per character. All reset at **midnight Ohio (US Eastern) time** automatically.

## Project Structure

```
hero-academy-bot/
├── src/
│   ├── index.js              # Bot entry point, event handling
│   ├── database.js           # SQLite database setup and queries
│   ├── deploy-commands.js    # Slash command registration script
│   ├── scheduler.js          # Midnight reset + leaderboard refresh
│   ├── utils/
│   │   ├── time.js           # Ohio time, class schedule helpers
│   │   ├── xp.js             # XP/money rolling, messages
│   │   └── leaderboard.js    # Leaderboard message builder
│   └── commands/
│       ├── help.js
│       ├── register.js
│       ├── class.js
│       ├── study.js
│       ├── train.js
│       ├── afterschool.js
│       ├── leaderboard.js
│       ├── list.js
│       ├── rename.js
│       ├── delete.js
│       ├── spend.js
│       └── donate.js
├── data/                     # SQLite database lives here (gitignored)
├── .env                      # Your secrets (gitignored)
├── .env.example
├── .gitignore
└── package.json
```
